﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EchoBot1
{
    public class UserProfile
    {
        public string Name { get; set; }
    }
}